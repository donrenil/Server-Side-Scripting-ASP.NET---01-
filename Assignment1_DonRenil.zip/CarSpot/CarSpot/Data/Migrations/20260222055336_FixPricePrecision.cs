﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CarSpot.Data.Migrations
{
   
    public partial class FixPricePrecision : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
