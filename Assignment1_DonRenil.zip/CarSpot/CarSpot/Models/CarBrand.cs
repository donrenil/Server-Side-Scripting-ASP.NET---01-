﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CarSpot.Models
{
    public class CarBrand
    {
        public int CarBrandId { get; set; }  // PK

        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        public string Country { get; set; } = string.Empty;

        public int FoundedYear { get; set; }

        // 1 brand -> many cars
        public List<Car> Cars { get; set; } = new();
    }
}