﻿using System.ComponentModel.DataAnnotations;

namespace CarSpot.Models
{
    public class Car
    {
        public int CarId { get; set; }  // PK

        [Required]
        public string ModelName { get; set; } = string.Empty;

        public decimal Price { get; set; }

        public int Year { get; set; }

        // FK
        public int CarBrandId { get; set; }

        // Navigation
        public CarBrand? CarBrand { get; set; }
    }
}